from pathlib import Path
import json,subprocess
from PIL import Image,ImageDraw
s=Path('/tmp/up07-m67-waiver-supplement/artifacts');o=Path('/tmp/up07-independent-visual');runs=json.load(open(s/'runs.json'));meta=[]
for view in ['pc','portrait','landscape']:
 rs=[r for r in runs if r['view']==view and r.get('route')in ['straight','ul','ur']];rows=[]
 for r in rs:
  frames=[];start=r['rows'][0]['t']/1000+.15
  for i in range(8):
   t=start+i*.04;f=o/'temp.png';subprocess.run(['ffmpeg','-threads','1','-v','error','-ss',str(t),'-i',str(s/f'{view}-production.webm'),'-frames:v','1','-y',str(f)],check=True);frames.append(Image.open(f).convert('RGB').copy());meta.append({'view':view,'route':r['route'],'seek':t})
  w,h=frames[0].size;row=Image.new('RGB',(w*8,h+25),'#bbb');d=ImageDraw.Draw(row)
  for i,im in enumerate(frames):row.paste(im,(i*w,25));d.text((i*w+2,4),f"{view}/{r['route']} t={start+i*.04:.3f}",fill='black')
  row.save(o/f'{view}-{r["route"]}-native-chronology.png');rows.append(row)
 (o/f'{view}-overview.png').unlink(missing_ok=True)
 # Route overview spatialhalf, chronology unchanged. Fullnative rows retained.
 w,h=rows[0].size;plate=Image.new('RGB',(w//2,h*3//2))
 for j,row in enumerate(rows):plate.paste(row.resize((w//2,h//2)),(0,j*(h//2)))
 plate.save(o/f'{view}-overview.png')
(o/'temp.png').unlink();(o/'seeks.json').write_text(json.dumps(meta,indent=2))
