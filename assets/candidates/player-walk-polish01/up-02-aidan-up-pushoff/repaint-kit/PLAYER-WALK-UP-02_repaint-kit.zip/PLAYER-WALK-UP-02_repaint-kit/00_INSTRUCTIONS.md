# PLAYER-WALK-UP-02｜エイダン後ろ姿・右足蹴り出しポーズ 描き直し依頼

THE WINDBOUND OATH のフィールド歩行素材です。正式素材を土台に、**脚の一部だけ**を描き直します。

## 収録ファイル

| ファイル | 内容 |
|---|---|
| `01_base_aidan_walk_up_03.png` | 土台。正式採用の後ろ姿歩行03（2048×1280、背景透過 RGBA） |
| `02_mask_repaint_white.png` | 描き直し範囲のマスク（**白＝描き直してよい／黒＝変更禁止**）。土台と同じ 2048×1280 |
| `03_mask_preview.png` | 土台に、描き直し範囲を赤紫で重ねた確認用の画像 |
| `04_guide_anchor_ground.png` | 地面の線（y=1229）、アンカー (1024,1230)、描き直し範囲の輪郭を描き込んだ案内図 |
| `references/R_boot_planted_up01.png`、`R_boot_planted_up06.png` | **右足の靴のデザイン参照**（画面右の、接地している靴） |
| `references/R_leg_in_base_up03.png` | 土台03の、置き換える右脚 |
| `references/pushoff_style_LEFT_up04.png`、`pushoff_style_LEFT_up02.png` | 蹴り出しの描き方（靴底の見え方・陰影・大きさ）の参照。**左足なので、靴の形はコピーしない** |
| `references/design_sheet_aidan_back_a.png`、`_b.png` | 後ろ姿の設定画 |

## 描いてほしい姿勢

- 後ろ姿で、エイダン**本人の右足（画面の右側の足）**を、体の後ろ（カメラ側）へ伸ばした**蹴り出し**の姿勢。
  - 膝は軽く曲げる
  - 踵を上げ、靴底をカメラに向ける
  - つま先は地面の線（y≈1229）に接する
- 左足（画面左）は土台03の絵のまま。接地して体重を支えている。
- 右足の靴は、**右足用の靴**として描く。デザインは `R_boot_planted_*` を参照し、左足の靴を左右反転して使わない。
- 蹴り出す足はカメラに近いので、左足より手前に重なり、少し大きく見える。
- 右の腿は、既存の白い裾・緑の外套の下から自然に出す。外套・裾の形は変えない。
- 膝・足首・靴の向きは解剖学的に自然に。足は体の中心へ傾けず、まっすぐ後ろ、またはやや外側へ伸ばす。

## サイズ・合成条件（必ず守る）

1. 出力は **2048×1280 の RGBA PNG（背景透過）** にする。トリミング・拡大縮小・キャンバスの位置ずらしはしない。
2. 変更するのは、マスクの**白い範囲だけ**。黒の範囲（顔・髪・外套・剣・左足など）は1画素も変えない。白い範囲から少しはみ出しても、取り込むときに正式の画素へ戻されます。
3. 地面の線は **y=1229**、アンカーは **(1024,1230)**。つま先の最下端を y=1229 に合わせる。
4. 背景・地面・影・市松模様・文字を描き込まない（白い範囲の中で、脚がない部分は透明のまま）。
5. 画風・色・質感・線の太さ・縮尺は、土台と同じにする。

## ChatGPT への依頼文（例）

> Attached: base image `01_base_aidan_walk_up_03.png` (2048×1280, transparent) and mask `02_mask_repaint_white.png`. Edit ONLY the white mask area. Redraw the character's anatomical RIGHT leg (the leg on the right side of the image; this is a back view) as a push-off pose: leg extended behind the body toward the viewer, knee slightly bent, heel lifted, sole facing the viewer, toe touching the ground line at y=1229. Keep the left leg, cloak, hem and everything outside the mask exactly unchanged. Use the right-boot design from `R_boot_planted_up01.png`; use `pushoff_style_LEFT_up04.png` only as a style reference for how a sole is shaded. Same art style, colors and scale. Output a 2048×1280 PNG with a transparent background, no ground or shadow.

## 納品後の処理（Claude が行います）

1. GitHub の PR #149 のブランチに追加してもらうか、チャットに添付してもらう。
2. マスクの外を正式の画素に戻して合成し、寸法・地面の線・透過・差分を検査する。
3. 5コマ構成（蹴り出し → 03 → 04 → 01 → 06、周期90、bob 25%）で連続再生を比較する。
4. Codex が独立QAを行い、ディレクターが採用を判断する。
