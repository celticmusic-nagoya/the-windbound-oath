# ANCHOR-RIG-BRIDGE-10

実測JSONと実フレームJSONを受け取り、BRIDGE-08 → BRIDGE-07の接地監査を実行する読み取り専用CLI。原本PNGやPR #229は変更しない。

```sh
python bridge10.py ANCHOR_MEASUREMENTS_UNAPPROVED.json REAL_FRAMES.json --out result.qa.json
python -m unittest test_bridge10.py -v
```

入力が欠ける場合は終了コード2（BLOCKED）。完全な入力があっても画像SHA値そのものの照合・視覚QA・Android QAは行わないため `realAssetVerified=false`、`adoptionReady=false`。

`REAL_FRAMES_EMPTY_TEMPLATE.json`は空欄の入力例であり、歩行データではない。BRIDGE-09ブラウザで保存した実測JSONを利用する。各方向の静止アンカーを歩行ポーズとして流用しない。閾値2pxは暫定値。

次の作業は測定JSONと実フレーム（画像、SHA、座標、接地イベント）を収集し、監査を実行すること。未提出のため本パッケージでは実歩行QAはBLOCKED。
